function logout(element) {
    element.innerText = "Logout";
}

var hidden = false;
function hide() {
    hidden = !hidden;
        document.getElementById('definition').style.visibility = 'hidden';
    
}
