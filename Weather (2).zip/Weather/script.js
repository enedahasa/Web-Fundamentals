function showAlert() {
    alert(" Loading weather report..");
  }

  var hidden = false;
  function remove() {
      hidden = !hidden;
          document.getElementById('fshi').style.visibility = 'hidden';
  }